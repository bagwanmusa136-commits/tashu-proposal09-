INSTRUCTIONS

1) Put your files in the same folder:
   - img1.jpg
   - img2.jpg
   - love.mp4
   - music.mp3

2) Upload all files to GitHub repository (root).

3) Enable GitHub Pages.

4) Use the GitHub Pages link to generate QR code.
